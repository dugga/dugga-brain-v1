
---------------------------------------------------------------------------------------------------
                               OpenRPGUI v1.3 (www.OpenRPGUI.com)

---------------------------------------------------------------------------------------------------


---------------------------------------------------------------------------------------------------
                                       Installation
---------------------------------------------------------------------------------------------------

!!!!!!!!!!!!
ExtJS is license under GPLv3, please read extjs_license.txt before installing the software
!!!!!!!!!!!!

:::Install Steps:::

1. Unzip the downloaded file to c:\temp (or the directory of your choice).

2. Issue the AS/400 command:
    CRTSAVF FILE(QGPL/ORU13) AUT(*ALL)

3. FTP the file oru13.savf from your PC to the AS/400 in BINARY mode
    into the save file ORU12 in library QGPL.

        3.01 - open a DOS prompt (Start -> Run -> enter 'cmd' and hit enter)
        3.02 - type the following into the DOS prompt
        3.03 - ftp 172.29.134.41    (replace the IP address with that of your iSeries)
        3.04 - when prompted enter profile and password
        3.05 - binary
        3.06 - lcd c:\temp          (where c:\temp is the location of the savf)
        3.07 - quote site namefmt 0
        3.08 - cd QGPL
        3.09 - put oru13.savf oru13.savf
        3.10 - quit


4. Restore the RPGUI library.

     RSTLIB SAVLIB(ORU13) DEV(*SAVF) SAVF(QGPL/ORU13)

5. Create an Apache server instance named MYORU.  Note you will want to be signed in with
   a profile that has *SECOFR and *SECADM capabilities because the INSTALL program adds a 
   member to a system source physical file and also runs a CHGAUT command against the 
   created IFS files and folders.  Note if you are running V5R3 there are portions of this
   that will fail because the CHGAUT command didn't have the SUBTREE() parm until V5R4 or
   V6R1 (works for sure on V6R1).  The first parm is the base library that the new 
   environment will be created from.  The second parm is the new environment name and the
   third parm is the port Apache will listen on.  When this is complete you will have a
   library named MYORU and folder /www/MYORU in the IFS that contains many different 
   resources.  You can run this command a second time with different values for parms
   2 and 3 to create another environment.

      CALL ORU13/INSTALL ('ORU13' 'MYORU' '81')
      


6. Start the OpenRPGUI Apache HTTP Server instance by typing in the below
    command.

    STRTCPSVR SERVER(*HTTP) HTTPSVR(MYORU)


7. Open your internet browser and enter the following. Substitute your IBM i ip address:

    http://<as400ip>:81/dspf/custmaint.html
       or
    http://<as400ip>:81/index.html

    You should see a page displaying the OpenRPGUI logo and the sample customer maintenance app.


---------------------------------------------------------------------------------------------------
                                      Requirements
---------------------------------------------------------------------------------------------------

- OpenRPGUI was created on an IBM i running V5R3 of OS/400 and is compiled down to V5R2

- *If* you need SSL functionality then cryptographic support needs to be installed on your iSeries.
  If you are on V5R4 or subsequent release then the SSL functionality already exists in the OS and
  doesn't need to be installed separately.  The SSL license program for V5R3 and previous releases
  is 5722AC3.

- OpenRPGUI requires Apache which is installed on 99% of all machines we come in contact with. 

---------------------------------------------------------------------------------------------------
                                      Contact
---------------------------------------------------------------------------------------------------
To get support please go here: http://openrpgui.com/support. I am notified of each email that is 
sent to the community support forum on that page.  It is good to send questions there vs. to me
directly because then others can help and it also shows the project is alive and well.

To contact me personally, Aaron Bartell, please shoot an email to aaronbartell@MowYourLawn.com

To gain access to the various forums please visit www.OpenRPGUI.com

---------------------------------------------------------------------------------------------------
                                     Updates
---------------------------------------------------------------------------------------------------
v1.3    - Upgrade to JSON v1.3.0.
        - Made QCLSRC,COMPILE more complete so it is easier to build the entire project with a 
          single call.
        - Changed the html files to use an ExtJS version from an online repository.  This saves
          from having to upload the entire ExtJS library (40MB+) to the IBM i.
        - Fixed a number of errors in the example programs.
        - Added in example programs from the latest articles (http://openrpgui.com/articles)
        - Introduced QRPGLESRC,EXTJS *SRVPGM. This is part of an example and I am using it as a
          test bed at this point. It has to do with this article:
          http://ibmsystemsmag.blogs.com/ibm_i_extra/2011/03/building-even-more-dynamic-code.html

v1.2    - Upgraded to JSON v1.2.2.  Had to change var += 1 to var = var + 1 to compile down to V5R2
        - Compiled down to V5R2.  Could go down to V5R1 if JSON.RPGLE program has the %float and 
          %int/h replaced.
        - Change HTTP member to have 30,9 instead of 32,9 for it's parms so we could compile down 
          V5R2.
        - Adding ORUDROID1 program which corresponds to the 4th IBMSystemsMag.com article in 
          Oct 2010 (the first Android one).
        - Added back in the BasicForm and LstItm examples and made them work with the latest version
          of OpenRPGUI.
        - Added back in the full source for the RPGNextGen utilities.  This was done so people with 
          bracket issues (i.e. [ and ] ) can more easily rectify the issue where it will translate
          the bracket values based on certain CCSID's being used.
        - Added QRPGLESRC,COMPILE which shows how to recompile the whole project.
        
v1.1    - Simplifying code base and the number of objects required at runtime. Introduced uiActn
          style processing.

v0.02b  - More samples and code updates
v0.01b  - Original

